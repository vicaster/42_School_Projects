ifconfig | grep 'ether' | sed 's/ether//' | sed '2d' | cut -d ' ' -f2
