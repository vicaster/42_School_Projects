/* ************************************************************************** */
/*                                                          LE - /            */
/*                                                              /             */
/*   ft_strdup.c                                      .::    .:/ .      .::   */
/*                                                 +:+:+   +:    +:  +:+:+    */
/*   By: vicaster <marvin@le-101.fr>                +:+   +:    +:    +:+     */
/*                                                 #+#   #+    #+    #+#      */
/*   Created: 2018/10/02 13:11:47 by vicaster     #+#   ##    ##    #+#       */
/*   Updated: 2018/10/02 16:59:28 by vicaster    ###    #+. /#+    ###.fr     */
/*                                                         /                  */
/*                                                        /                   */
/* ************************************************************************** */

#include <stdlib.h>

int		ft_strlen(char *src)
{
	int		i;

	i = 0;
	while (src[i])
		i++;
	i--;
	return (i);
}

char	*ft_strdup(char *src)
{
	char	*dest;
	int		size;

	dest = (char*)malloc(sizeof(*dest) * (ft_strlen(src) + 1));
	size = 0;
	while (src[size])
	{
		dest[size] = src[size];
		size++;
	}
	dest[size] = '\0';
	return (dest);
}
