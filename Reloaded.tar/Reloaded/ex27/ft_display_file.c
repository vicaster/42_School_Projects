/* ************************************************************************** */
/*                                                          LE - /            */
/*                                                              /             */
/*   ft_display.c                                     .::    .:/ .      .::   */
/*                                                 +:+:+   +:    +:  +:+:+    */
/*   By: vicaster <marvin@le-101.fr>                +:+   +:    +:    +:+     */
/*                                                 #+#   #+    #+    #+#      */
/*   Created: 2018/10/02 19:06:17 by vicaster     #+#   ##    ##    #+#       */
/*   Updated: 2018/10/02 20:23:20 by vicaster    ###    #+. /#+    ###.fr     */
/*                                                         /                  */
/*                                                        /                   */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>

int		ft_display(char **av)
{
	int		fd;

	fd = open(av[1], O_RDONLY);
	if (fd == -1)
	{
		write(2, "open() error\n", 13);
		return (1);
	}
	while (read(fd, &av[1], 1) != 0)
		write(1, &av[1], 1);
	if (close(fd) == -1)
	{
		write(2, "close() error\n", 14);
		return (1);
	}
	return (0);
}

int		main(int ac, char **av)
{
	if (ac == 1)
	{
		write(2, "File name missing.\n", 19);
		return (1);
	}
	if (ac == 2)
	{
		ft_display(av);
	}
	else
	{
		write(2, "Too many arguments.\n", 20);
		return (1);
	}
	return (0);
}
